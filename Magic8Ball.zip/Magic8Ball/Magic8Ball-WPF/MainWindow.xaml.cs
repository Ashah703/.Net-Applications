﻿using Magic8Ball_Logic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Magic8Ball_WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();





        }

        private void BtnAnswer_Click(object sender, RoutedEventArgs e)
        {
            Magic8Ball ballResponse = new Magic8Ball();

            
            ballResponse.SetStandard();
            ballResponse.Shake();
            String _question = txtAskQuestion.Text;

            string analyzing = "Searching the mystic realms (RAM) for an answer.";
            string error = "Ask a question first.";
            
            // The code below prompts the user an error message, when a question is not typed. 

            if (_question.Length == 0)
            {
                MessageBox.Show(error);
            }
            else
            {
                MessageBox.Show(analyzing);
                String answer = ballResponse.ShowAnswer();
                txtPathAnswer.Text = ("The answer to your question '" + _question + "' is '" + answer + "'.");
            }
                
            

           
        }
    }
}