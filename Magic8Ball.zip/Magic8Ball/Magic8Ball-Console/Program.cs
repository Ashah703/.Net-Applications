﻿// Akash Shah
// Magic 8 ball 
// IT 330


using Magic8Ball_Logic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Magic8Ball_Console
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Let's play some Magic 8 Ball!");
            Magic8Ball ballResponse = new Magic8Ball();


            //The code below provides different set of answers

            ballResponse.SetStandard();
            String _askQuestion = "";
            string _userMessage= "";

        // The code below creates the functionality of the Magic 8 ball


            do
            {
                Console.WriteLine(" ");
                Console.WriteLine("Please click on one of the options below to get started");
                Console.WriteLine("(S)hake the Ball");
                Console.WriteLine("(A)sk a Question");
                Console.WriteLine("(G)et the Answer");
                Console.WriteLine("(E)xit");
                Console.WriteLine("Enter S, A , G, or E:");
                _userMessage = Console.ReadLine().ToUpper();
                if (_userMessage == "S")
                {
                    ballResponse.Shake();
                    Console.WriteLine("Searching the mystic realms (RAM) for an answer.");
                }
                else if (_userMessage == "A")
                {
                    Console.ForegroundColor = ConsoleColor.DarkGreen;
                    Console.WriteLine("What is your question?");
                    Console.ForegroundColor = ConsoleColor.White;
                    _askQuestion = Console.ReadLine();

                }
                else if (_userMessage == "G")
                {
                    String answer = ballResponse.ShowAnswer();
                    Console.ForegroundColor = ConsoleColor.Green; // the text changes to green when the user presses "G"
                    Console.WriteLine("The answer to your question '" + _askQuestion + "' is '" + answer + "'.");
                    Console.ForegroundColor = ConsoleColor.White;

                }
                else if (_userMessage == "E")
                {
                    break;
                }
            }

            while (_userMessage != "");

        }
    }
}
