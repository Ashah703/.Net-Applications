﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Magic8Ball_Logic
{

    public class Magic8Ball
    {
        private List<string> _answers;
        private int _recentSelection;
        public Magic8Ball()
        {


            _answers = new List<string>();


        }

        // The code below stores the questions for the magic 8 ball
        public void SetChange()
        {
            _answers.Add("Not today");
            _answers.Add("What type of question is this");
            _answers.Add("Please ask another question");
            _answers.Add("I hope you're kidding");
            _answers.Add("If this is what you really want");
            _answers.Add("Why did you just ask me this");
            _answers.Add("So now you need something from me");
            _answers.Add("Wait you said something");
            _answers.Add("Not any time soon");
            _answers.Add("That was a very silly question to ask me");
            _answers.Add("Stop asking me boring questions");
            _answers.Add("Maybe someday");
            _answers.Add("When the sun becomes blue and the sky turns yellow");
            _answers.Add("Sorry not going to happen");
            _answers.Add("How could you say something like this");
            _answers.Add("Yes it is certain");
            _answers.Add("no it is not certain");
            _answers.Add("Your questions are still boring me");
            _answers.Add("You're putting me to sleep");
            _answers.Add("Sure");

        }
        public void SetStandard()
        {
            _answers.Add("It is certain.");
            _answers.Add("It is decidedly so.");
            _answers.Add("Without a doubt.");
            _answers.Add("Yes - definitely.");
            _answers.Add("You may rely on it.");
            _answers.Add("As I see it, yes.");
            _answers.Add("Most Likely.");
            _answers.Add("Outlook good.");
            _answers.Add("Yes.");
            _answers.Add("Signs point to yes.");
            _answers.Add("Reply hazy, try again.");
            _answers.Add("Ask again later.");
            _answers.Add("Better not tell you now.");
            _answers.Add("Cannot predict now.");
            _answers.Add("Concentrate and ask again.");
            _answers.Add("Don't count on it.");
            _answers.Add("My reply is no.");
            _answers.Add("My sources say no.");
            _answers.Add("Outlook not so good.");
            _answers.Add("Very doubtful.");
        }

        public Magic8Ball(List<string> answers)
        {

            _answers = answers;
        }

        public void Shake()
        {
            Random pick = new Random();
            for (int i = 0; i < _answers.Count; i++)
            {
                _recentSelection = pick.Next(_answers.Count);
            }

        }

        public string ShowAnswer()
        {
            return _answers[_recentSelection];
        }

        public int AnswerCount
        {
            get { return _answers.Count; }
        }

        public override string ToString()
        {
            string concatenate = String.Join("\n", _answers.ToArray());
            return concatenate;
        }
    }
}